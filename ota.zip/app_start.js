const delay = require('delay'); // npm install delay

//-----------------------------------------------------------------------------------------
//   VC app_start Function
//-----------------------------------------------------------------------------------------
//- Raspi Start > Auto load atm_start.js > use forever to create new log file with timestamp > execute forever > exit 
//-----------------------------------------------------------------------------------------
var macAddress = '0';
var d = new Date();
var hrs = ('0' + d.getHours()).substr(-2);
var min = ('0' + d.getMinutes()).substr(-2);
var sec = ('0' + d.getSeconds()).substr(-2);
var year = d.getFullYear();
var month = ('0' + (d.getMonth() + 1)).substr(-2);
var date = d.getFullYear() + ('0' + (d.getMonth() + 1)).substr(-2) + ('0' + d.getDate()).substr(-2);
var data_tmp = date + '-' + hrs + min + sec;
var root_dir = '/home/pi/app_vc/'
var dir_prod = root_dir + 'log_forever/' + year + month;
var filename = '0';

create_forever_log();

async function create_forever_log() {

    await getMacAddress();
    return new Promise(async function(resolve, reject) {
        var fs = require('fs');

        console.log('---   VideoCall MODE  ---');
        //console.log('- (log): folder/filename: ' + dir_prod + filename );
        if (!fs.existsSync(root_dir + 'log_forever/')) {
            await fs.mkdirSync(root_dir + 'log_forever/');
        }
        if (!fs.existsSync(dir_prod)) {
            await fs.mkdirSync(dir_prod);
        }

        await delay(1000); //wait 10sec before start (to prevent loop)
        process_forever();
        resolve(1);
    })
}

//--- Write Forever Log File --------------------------------------
async function process_forever() {
    const util_exec = require('util');
    const exec = util_exec.promisify(require('child_process').exec);

    var date = new Date(); // create a new date object
    var localTime = date.toLocaleTimeString(); // get the local time
    console.log(localTime); // print the local time

    console.log("- Wait for NTP time...");
    await exec('sudo timedatectl set-ntp true');
    await delay(30000); //wait for 30sec for time udpate first
    console.log(localTime); // print the local time

    console.log("- Start forever command...");
    filename = '/for_' + macAddress + '-' + data_tmp + '.txt';
    console.log("- Start VC :" + dir_prod + filename);
    //exec('chromium-browser --force-fieldtrials=WebRTC-SupportVP9SVC/EnabledByFlag_2SL3TL --webrtc-max-cpu-consumption-percentage=100 --no-first-run --noerrdialogs --disable-notifications --check-for-update-interval=604800 --start-fullscreen --start-maximized --app=http://localhost:5050');
    await exec('sudo /usr/local/lib/node_modules/forever/bin/forever start -a -l ' + dir_prod + filename + ' /home/pi/app_vc/app.js');
    await delay(2000);

    //await exec('sleep 3');
    await process_tail();
}

function process_tail() {
    Tail = require('tail').Tail;
    tail = new Tail(dir_prod + filename);

    tail.on("line", function(data) {
        console.log(data);
    });

    tail.on("error", function(error) {
        console.log('ERROR: ', error);
    });
}

//--- Get Mac Address ----------------------
function getMacAddress() {

    var macaddress = require('macaddress');

    return new Promise(function(resolve, reject) {
        macaddress.one('eth0', function(err, mac) {
            macAddress = mac;
            macAddress = macAddress.replace(/-/g, '');
            macAddress = macAddress.replace(/:/g, '');
            console.log('- VC Mac Address: ' + macAddress.slice(-4));
            //macAddress = 'b827eb825c1b';    //testing set
            console.log('- Prefix Mac Address: ' + macAddress.slice(-4));
            resolve(1);
        });
    })
}
