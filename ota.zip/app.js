// npm init
// npm install 
// sudo npm install firebase firebase-admin
// sudo npm install forever -g
// sudo npm i twilio console-stamp util delay moment request fs tail external-ip ip ping socket.io socket.io-client express http 
// sudo -Es     >>  sudo npm i onoff macaddress reboot google-spreadsheet

'use strict';
require('console-stamp')(console, { pattern: 'dd/mm/yyyy HH:MM:ss.l' }); //console.log, info, warn, error, dir
const util = require('util');
const exec = util.promisify(require('child_process').exec);
var delay = require('delay');
var moment = require('moment');
var today = new Date();
console.log(today);

//--- Global Variable ---
global.app_version = 'v2.9'
global.test_mode = 1;
global.firebase = require("firebase");
global.db;
global.fb_signin = 0;
global.fb_signin_cnt = 0;
global.External_IP = '0.0.0.0';
global.Internal_IP = '0.0.0.0';
global.Device_MAC = '0.0.0.0';
global.internet_alive = 0;
global.button_set = 0;
global.ext_ip_set = 0;
global.firebaseConfig = '';
global.Telegram_BOT_TOKEN = '';
global.Telegram_CHAT_ID = '';
global.Twilio_SID = '';
global.Twilio_TOKEN = '';
global.Store_Label = '';
global.Store_Link = '';
global.raspi_temperature = '';
global.WebCam_link = '';

global.gs_CallStart = '';
global.gs_CallEnd = '';
global.gs_User = '';
global.gs_Process = '';

global.VC_Domain = 'meet.jit.si';
global.PhoneContact = '+6055415414';
global.PhoneSupervisor = '';
global.AppMessage = "Customer call in.."
global.Msg_Calling = 'Please wait while connecting to our Customer Service team... ';
global.Msg_MissCall = 'Sorry we are busy, please try again later or call us on ';
global.Time_MissCall = 30;
global.Time_PhoneCall = 30;
global.Gen_Link = [];
global.Gen_Link_Label = [];
global.Dev_Link = [];
global.Report_id = []; //1: 2021 -- 8: 2028 
global.vlink_count = 10; //10 Max videos
global.video_list = '0';
global.Web_command = '';

const cm = require('./fc_common'); //put after the global variable

//--- Local Variable ---
var fb_reset = 0;
var WebCam_start = 0;
var Web_timer = 0;
var Web_message = 0;
var web_ready = 0;
var web_ready_cnt = 0;
var dev_status = 0;
var dev_process = 0;
var PhoneCall_cnt = 0;
var MissCall_set = 0;
var Calling_set = 0;
var WebCam_link_timer = 0;
var Dev_status_timer = 0;

//-----------------------------------------------------
//   START
//-----------------------------------------------------
init();

async function init() {

    console.log("- App Version: " + app_version);
    const now = moment().valueOf();
    var timeStamp = parseInt(now);
    console.log('- timeStamp: ' + timeStamp);

    var macaddress = require('macaddress');
    macaddress.one('eth0', function(err, mac) {
        Device_MAC = mac.replace(/-/g, '');
        Device_MAC = Device_MAC.replace(/:/g, '');
        console.log('- Device_MAC: ' + Device_MAC.slice(-4));
    });

    var ip = require('ip');
    Internal_IP = await ip.address().toString();
    console.log('- Internal_IP: ' + Internal_IP);
    cm.ping_internet();

    // Initialize Firebase
    cm.init_firebase();
}

//-----------------------------------------------------
//   Loop Function
//-----------------------------------------------------
setInterval(loop_100mSec, 100); //0.1sec
setInterval(loop_1sec, 1000); //1sec
setInterval(loop_1min, 60000); //60sec

function loop_100mSec() {

    if (button_set == 1) { // Button pressed 
        button_set = 0;
        keyDown('a');
    }

    if (ext_ip_set == 1) { // New Ext IP 
        ext_ip_set = 0;
        fb_sign_in();
    }
}

function loop_1sec() {

    if (WebCam_start != 0 && fb_signin == 1) {
        Web_timer++;
        var timer_tmp = moment.utc(Web_timer * 1000).format('HH:mm:ss');
        db.ref('Status/' + Device_MAC).update({
            Timer: timer_tmp,
        });
    }

    if (WebCam_start == 1) {

        if (MissCall_set == 0) {
            Web_message = Msg_Calling + Web_timer;
            if (Web_timer >= Time_MissCall && Calling_set == 0) {
                MissCall_set = 1;
                console.log("- Missed Call..");
                Web_message = Msg_MissCall + PhoneContact;
                var dateTime = moment().format('YY/MM/DD - h:mm:ss a');
                cm.send_alert_msg(dateTime + ': ' + Store_Label + ' missed call..');
            }
        }

        if (MissCall_set == 1) {
            fb_update_process('Missed Call');
            WebCam_start = 99;
            PhoneCall_cnt = Time_PhoneCall;
        }

        if (internet_alive == 0) {
            console.error("- Internet Down..");
            Web_message = 'Internet Offline! Sorry, please try again later or call us on ' + PhoneContact;
            MissCall_set = 1;
        }

        if (fb_signin == 0) {
            console.error("- Signin Error..");
            Web_message = 'Server Error! Sorry, please try again later or call us on ' + PhoneContact;
            MissCall_set = 1;
        }
    }

    if (WebCam_start == 99) {
        if (PhoneCall_cnt != 0) {
            PhoneCall_cnt--;
            if (PhoneCall_cnt == 0) {
                console.log('- PhoneCall_cnt = 0 > end_call() > Web Reload');
                end_call();
            }
        }
    }
}

async function loop_1min() {

    //console.log('x'); 
    cm.ping_internet();

    if (internet_alive == 1 && fb_signin == 1) {

        fb_update_timestamp(); //for system online status

        if (WebCam_start == 0) {
            //Cpu Idle >> top -b -n 1 | sed -n "s/^%Cpu.*ni, \([0-9.]*\) .*$/\1% Idle/p"
            //Cpu Usage >> top -n1 | awk '/Cpu\(s\):/ {print $2}'
            cm.read_temperature();
            var raspi_temp = parseInt(raspi_temperature) + '°C';
            //console.log("- Temperature: " + raspi_temp);

            const time_unix = moment().valueOf();
            var dateTime = moment().format('YY/MM/DD-h:mm:ss a');

            db.ref('OnlineStatus/' + Device_MAC).update({
                lastOnlineDate: time_unix + ',' + dateTime
            });

            db.ref('DeviceID/' + Device_MAC).update({
                System: raspi_temp,
                TimeStamp: firebase.database.ServerValue.TIMESTAMP,
                lastOnlineDate: time_unix + ',' + dateTime
            });

            // Update new vc link
            if (WebCam_link_timer > 30) { //reset web link after N min
                fb_set_link();
            }
            WebCam_link_timer++;

            // Update system online status
            if (Dev_status_timer > 5) {
                Dev_status_timer = 0;
                fb_update_status('Ready');
            }
            Dev_status_timer++;
        }
    }

    if (web_ready == 0) {
        web_ready_cnt++;
        if (web_ready_cnt > 5) {
            console.error("- (1min) web_ready == 0 > 5min >> Reboot...");
            cm.system_post_gsheet('System', 'Reboot (Web Error)');
            sys_reboot();
        }
    } else {
        web_ready_cnt = 0;
    }
}


//-----------------------------------------------------
//   Firebase Function
//-----------------------------------------------------
async function fb_sign_in() {

    if (fb_signin == 0 && fb_signin_cnt < 10) {
        console.log('- (fb) Prepare Sign-In... ');
        var email = Device_MAC + '@xim-vc.app';
        var password = Device_MAC + '@xim';
        await firebase.auth().signInWithEmailAndPassword(email, password).then(function() {
            // Sign-in successful.
            fb_signin = 1;
            console.log("- (fb) Sign-in successful..");
            cm.fb_read_setting_once();
            fb_read_setting_on();
        }).catch(function(error) {
            fb_signin_cnt++;
            console.error("!!! ERROR (Sign-in failed): " + error.code);
        });
    }

    if (fb_signin == 1) {
        console.log('- Firebase connection Reset..');
        await firebase.database().goOffline();
        await firebase.database().goOnline();
    }
}

//--- fb_read_setting -----------------------------------
async function fb_read_setting_on() {

    //--- VideoCall Server Domain ----
    await db.ref('GeneralSetting/VC_Domain').on("value", function(snapshot) {
        VC_Domain = snapshot.val();
        console.log('- (FB On) VC_Domain: ' + VC_Domain);
    });

    await db.ref('Status/' + Device_MAC + '/Process').on("value", function(snapshot) {
        dev_process = snapshot.val();
        console.log('- (FB On) dev_process: ' + dev_process);

        if (dev_process != 'None') {
            if (gs_CallStart == '') {
                gs_CallStart = moment().format("DD/MM/YYYY HH:mm:ss");
                console.log('- gs_CallStart: ' + gs_CallStart);
            }
            if (gs_Process == '' || dev_process == 'Missed Call') {
                gs_Process = dev_process;
                console.log('- gs_Process: ' + gs_Process);
            }
            if (dev_process == 'Calling') {
                Calling_set = 1;
                if (WebCam_start == 0) {
                    keyDown('b');
                }
            }
            if (dev_process == 'End Call') {
                keyDown('c');
            }
        }
    });

    await db.ref('Status/' + Device_MAC + '/User').on("value", function(snapshot) {
        var user_tmp = snapshot.val();
        if (user_tmp != '-') {
            db.ref('UserSetting/' + user_tmp).update({
                Process: 'Calling',
                Link: WebCam_link,
                StoreID: Device_MAC,
                VcDomain: VC_Domain,
                Timestamp: firebase.database.ServerValue.TIMESTAMP
            });

            db.ref('Status/' + Device_MAC + '/Username').once("value", function(snapshot) {
                var username_tmp = snapshot.val();
                if (username_tmp != null && username_tmp != '-') {
                    gs_User = username_tmp;
                } else {
                    gs_User = user_tmp;
                }
                console.log('- gs_User: ' + gs_User);
            });
        }
    });

    await db.ref('DeviceID/' + Device_MAC + '/TestKey').on("value", function(snapshot) {
        var testkey = snapshot.val();
        if (testkey == null) {
            db.ref('DeviceID/' + Device_MAC).update({
                TestKey: 0,
            });
        }
        if (testkey != 0) {
            keyDown(testkey);
            db.ref('DeviceID/' + Device_MAC).update({
                TestKey: 0,
            });
        }
    });

    //--- SET ONLINE/OFFLINE STATUS ---
    await db.ref('Status/' + Device_MAC).onDisconnect().update({
        Status: 'Offline',
    });
}

//-----------------------------------------------------
//   Process Function
//-----------------------------------------------------
function end_call() {

    if (gs_CallEnd == '' && gs_CallStart != '') {
        gs_CallEnd = moment().format("DD/MM/YYYY HH:mm:ss");
        console.log('- gs_CallEnd:' + gs_CallEnd);
        cm.post_gsheet();
    }

    WebCam_start = 88;
    if (fb_signin == 1) {
        if (MissCall_set == 0) { //no missed call
            fb_update_process('None');
        }
    }
}

async function fb_set_link() {
    const now = moment().valueOf();
    var timeStamp = parseInt(now);

    if (fb_signin == 1) {
        WebCam_link_timer = 0;
        //https://meet.jit.si/j5cevk/xim-vc.7aca5b75
        WebCam_link = "j5cevk/xim-vc." + Device_MAC.slice(-6) + timeStamp;
        console.log('- Set Store_Link: ' + WebCam_link);

        db.ref('Status/' + Device_MAC).update({
            Link: WebCam_link,
        });
    }
}

async function fb_read_process() {

    if (fb_signin == 1) {
        db.ref('Status/' + Device_MAC + '/Process').once("value", function(snapshot) {
            dev_process = snapshot.val();
            console.log('- (FB Once) dev_process: ' + dev_process);
            if (dev_process == 'Calling') {
                keyDown('b');
            } else if (dev_process != 'None' && dev_process != 'Missed Call') {
                fb_update_process('None');
            }
        });
    }
}

//--- fb_update_xxx -----------------------------------
async function fb_update_status(status) {

    if (fb_signin == 1) {
        dev_status = status;
        console.log('- (FB Update) dev_status: ' + dev_status);
        var dateTime = moment().format('YY/MM/DD - h:mm:ss a');
        await db.ref('Status/' + Device_MAC).update({
            Status: dev_status,
            DateTime: dateTime
        });
    }
}

async function fb_update_process(process) {

    if (fb_signin == 1) {
        dev_process = process;
        await db.ref('Status/' + Device_MAC).update({
            Process: dev_process,
            Status: 'Online',
        });
        db.ref('AppSetting/app1@xim-vc_app').update({
            Process: dev_process,
        });
        db.ref('AppSetting/app2@xim-vc_app').update({
            Process: dev_process,
        });

        if (dev_process == 'None') {
            WebCam_start = 0;
            Web_timer = 0;
            db.ref('Status/' + Device_MAC).update({
                Timer: '00:00:00',
            });
        }
    }
}

function fb_update_timestamp() {

    if (fb_signin == 1) {
        db.ref('Status/' + Device_MAC).update({
            Timestamp: firebase.database.ServerValue.TIMESTAMP
        });
    }
}

//-----------------------------------------------------
//   Web Function > http://localhost:5050/
//-----------------------------------------------------
var http = require('http');
var express = require('express');
const { link } = require('fs');
var app = express();
var server = http.createServer(app);
var io = require('socket.io').listen(server); // Pass a http.Server instance to the listen method

server.listen(5050); // The server should start listening

app.get('/', function(req, res) {
    res.sendFile(__dirname + '/index.html');
});

//app.use('/cache', express.static(__dirname + '/cache'));
app.use('/', express.static(__dirname));

let interval;
io.on("connection", socket => {
    console.log("- (web) Web Start..");
    socket.on("WebStatus", (data) => {
        console.log("- (web) WebStatus: " + data.WebStatus);
        if (data.WebStatus == 'Ready') {
            clearInterval(interval);
            web_ready = 1;
            WebCam_start = 0;
            Web_timer = 0;
            Web_message = '';
            Web_command = '';
            Calling_set = 0;
            Store_Link = '';
            PhoneCall_cnt = 0;
            fb_set_link(); //update new videocall link every reload to prevent multiple call
            fb_update_status('Ready');
            fb_read_process();
            fb_update_timestamp();
            interval = setInterval(() => getApiAndEmit(socket), 100);
        }
        if (data.WebStatus == 'CS_Joined') {
            MissCall_set = 0;
            console.log("- (web) CS Joined..");
        }
        if (data.WebStatus == 'CS_Left') {
            //Web_message = 'Please wait while reconnecting...';
            console.log("- (web) CS_Left..");
        }
        if (data.WebStatus == 'micError' || data.WebStatus == 'cameraError') {
            console.error("- (web) Webcam Error > Reboot..");
            cm.system_post_gsheet('System', 'Reboot (Cam Error)');
            sys_reboot();
        }
    });
    socket.on("disconnect", () => {
        web_ready = 0;
        console.log("- (web) Web disconnected..");
    });
});

const getApiAndEmit = async socket => {
    clearInterval(interval);
    try {
        if (web_ready == 1) {
            var dateTime = moment().format('YY/MM/DD - h:mm:ss a');
            socket.emit('web_dateTime', {
                web_dateTime: dateTime,
            });
            socket.emit('web_status', {
                VC_Domain: VC_Domain,
                WebCam_link: WebCam_link,
                WebCam_start: WebCam_start,
                Web_message: Web_message,
                Web_command: Web_command,
                video_list: video_list,
            });
        }
    } catch (error) {
        console.error(`- (web) Socket Error: ${error.code}`);
    }
    interval = setInterval(() => getApiAndEmit(socket), 100);
};

//-----------------------------------------------------
//   Test Key Function
//-----------------------------------------------------
/*
var stdin = process.stdin;
stdin.setRawMode(true);
stdin.resume();  // resume stdin in the parent process
stdin.setEncoding('utf8');
stdin.on('data', function (key) {
    keyDown(key)
});*/
async function keyDown(key) {

    console.log("- [TEST] Key: " + key);
    if (key == null) {
        return;
    }

    switch (key) {
        case '\u0003':
            process.exit();
            break; // ctrl-c ( end of text )
        case 'a': //Button Call Out
            if (WebCam_start == 0) {
                WebCam_start = 1;
                MissCall_set = 0;
                Web_timer = 0;
                console.log("- (a) WebCam_start = 1");
                //cm.ping_internet();
                if (fb_signin == 0) {
                    console.log("- (a) ERROR >> fb_signin == 0");
                } else {
                    gs_CallStart = moment().format("DD/MM/YYYY HH:mm:ss");
                    console.log('- gs_CallStart: ' + gs_CallStart);
                    cm.broadcastMessage(Store_Label, AppMessage);
                    fb_update_process('Call In');
                }
            }
            break;

        case 'b': //CS Call In
            Web_timer = 0;
            MissCall_set = 0;
            if (WebCam_start != 1) {
                console.log("- (b) WebCam_start = 1");
                WebCam_start = 1;
            }
            break;

        case 'c': //CS Clear 
            console.log('- (c) end_call() > Web Reload');
            MissCall_set = 0;
            end_call();
            break;

        case 'n':
            console.log('- (d) Send notification..');
            cm.broadcastMessage(Store_Label, AppMessage);
            break;

        case 'r': //reboot
            console.log("- [TEST] Reboot...");
            cm.system_post_gsheet(gs_User, 'Reboot (User)'); //update to google sheet
            sys_reboot();
            break;

        case 't': //on display
            console.error("- [TEST] On display...");
            await exec('vcgencmd display_power 1');
            break;

        case 'u': //off display
            console.error("- [TEST] Off display...");
            await exec('vcgencmd display_power 0');
            break;
    }
}

async function sys_reboot() {
    fb_update_status('Reboot');
    await delay(3000);
    require('reboot').reboot();
}

